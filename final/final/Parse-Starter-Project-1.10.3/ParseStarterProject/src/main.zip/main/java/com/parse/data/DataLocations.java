package com.parse.data;

/**
 * Created by rethinavel on 26/11/15.
 */
public class DataLocations {

    private int locationId = 0;
    private String locationName = "";

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public int getLocationId() {
        return locationId;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }
}
